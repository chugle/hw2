# -*- coding: utf-8 -*-
### required - do no delete
def user(): return dict(form=auth())
def download(): return response.download(request,db)
def call(): return service()
### end requires
def index():
    return dict()

def error():
    return dict()

@auth.requires_login()
def course_manage():
    form = SQLFORM.smartgrid(db.t_course,onupdate=auth.archive)
    return locals()

@auth.requires_login()
def homework_manage():
    form = SQLFORM.smartgrid(db.t_homework,onupdate=auth.archive)
    return locals()

@auth.requires_login()
def question_manage():
    form = SQLFORM.smartgrid(db.t_question,onupdate=auth.archive)
    return locals()

@auth.requires_login()
def answer_manage():
    form = SQLFORM.smartgrid(db.t_answer,onupdate=auth.archive)
    return locals()

@auth.requires_login()
def score_manage():
    form = SQLFORM.smartgrid(db.t_score,onupdate=auth.archive)
    return locals()

@auth.requires_login()
def netdiskfile_manage():
    form = SQLFORM.smartgrid(db.t_netdiskfile,onupdate=auth.archive)
    return locals()

