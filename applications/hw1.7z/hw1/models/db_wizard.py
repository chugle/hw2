### we prepend t_ to tablenames and f_ to fieldnames for disambiguity


########################################
db.define_table('t_netdiskfile',
    Field('f_by_who', type='string',
          label=T('By Who')),
    Field('f_filename', type='string',
          label=T('Filename')),
    Field('f_type', type='string',
          label=T('Type')),
    Field('f_size', type='string',
          label=T('Size')),
    auth.signature,
    format='%(f_by_who)s',
    migrate=settings.migrate)

db.define_table('t_netdiskfile_archive',db.t_netdiskfile,Field('current_record','reference t_netdiskfile',readable=False,writable=False))

########################################
db.define_table('t_course',
    Field('f_title', type='string',
          label=T('Title')),
    Field('f_grade', type='string',
          label=T('Grade')),
    Field('f_number', type='string',
          label=T('Number')),
    Field('f_content', type='string',
          label=T('Content')),
    Field('f_file', type='string',
          label=T('File')),
    auth.signature,
    format='%(f_title)s',
    migrate=settings.migrate)

db.define_table('t_course_archive',db.t_course,Field('current_record','reference t_course',readable=False,writable=False))

########################################
db.define_table('t_answer',
    Field('f_quesiton_id', type='string',
          label=T('Quesiton Id')),
    Field('f_by_who', type='string',
          label=T('By Who')),
    Field('f_content', type='string',
          label=T('Content')),
    auth.signature,
    format='%(f_quesiton_id)s',
    migrate=settings.migrate)

db.define_table('t_answer_archive',db.t_answer,Field('current_record','reference t_answer',readable=False,writable=False))

########################################
db.define_table('t_question',
    Field('f_title', type='string',
          label=T('Title')),
    Field('f_course', type='reference t_course',
          label=T('Course')),
    Field('f_number', type='string',
          label=T('Number')),
    Field('f_content', type='string',
          label=T('Content')),
    Field('f_standard_answer', type='string',
          label=T('Standard Answer')),
    auth.signature,
    format='%(f_title)s',
    migrate=settings.migrate)

db.define_table('t_question_archive',db.t_question,Field('current_record','reference t_question',readable=False,writable=False))

########################################
db.define_table('t_score',
    Field('f_name', type='string',
          label=T('Name')),
    auth.signature,
    format='%(f_name)s',
    migrate=settings.migrate)

db.define_table('t_score_archive',db.t_score,Field('current_record','reference t_score',readable=False,writable=False))

########################################
db.define_table('t_homework',
    Field('f_course_id', type='string',
          label=T('Course Id')),
    Field('f_by_who', type='string',
          label=T('By Who')),
    Field('f_file', type='string',
          label=T('File')),
    Field('f_score', type='reference t_score',
          label=T('Score')),
    auth.signature,
    format='%(f_course_id)s',
    migrate=settings.migrate)

db.define_table('t_homework_archive',db.t_homework,Field('current_record','reference t_homework',readable=False,writable=False))
