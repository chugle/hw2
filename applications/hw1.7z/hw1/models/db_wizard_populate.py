from gluon.contrib.populate import populate
if db(db.auth_user).isempty():
     populate(db.auth_user,10)
     populate(db.t_netdiskfile,10)
     populate(db.t_course,10)
     populate(db.t_answer,10)
     populate(db.t_question,10)
     populate(db.t_score,10)
     populate(db.t_homework,10)
