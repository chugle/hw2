response.title = settings.title
response.subtitle = settings.subtitle
response.meta.author = '%(author)s <%(author_email)s>' % settings
response.meta.keywords = settings.keywords
response.meta.description = settings.description
response.menu = [
(T('Index'),URL('default','index')==URL(),URL('default','index'),[]),
(T('Course'),URL('default','course_manage')==URL(),URL('default','course_manage'),[]),
(T('Homework'),URL('default','homework_manage')==URL(),URL('default','homework_manage'),[]),
(T('Question'),URL('default','question_manage')==URL(),URL('default','question_manage'),[]),
(T('Answer'),URL('default','answer_manage')==URL(),URL('default','answer_manage'),[]),
(T('Score'),URL('default','score_manage')==URL(),URL('default','score_manage'),[]),
(T('Netdiskfile'),URL('default','netdiskfile_manage')==URL(),URL('default','netdiskfile_manage'),[]),
]