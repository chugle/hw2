# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a samples controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
## - call exposes all registered services (none by default)
#########################################################################

from gluon.tools import Crud

def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simple replace the two lines below with:
    return auth.wiki()
    """
    response.flash = T("Welcome to web2py!")
    grid = SQLFORM.grid(db.course)
    return dict(grid=grid)

def course_list():
    grid = SQLFORM.grid(db.course)
    return dict(grid=grid)

def study():
    keshi_id=request.args[0]
    record=db.keshi[keshi_id]
    kecheng_id=record.kecheng
    curd=Crud(db)
    lianxi_url=A('lianxi',_href=URL('lianxi/%s'%kecheng_id))
    zuoye_url=A('zuoye',_href=URL('zuoye/%s'%kecheng_id))
    defen_url=A('defen',_href=URL('defen/%s'%kecheng_id))
    return dict(keshi_id=keshi_id,lianxi_url=lianxi_url,zuoye_url=zuoye_url,defen_url=defen_url,
                form=curd.read(db.course,kecheng_id))
    
def defen():
    zuozhe=auth.user_id
    keshi_id=request.args[0]
    rows=db((db.zuoti.zuozhe==zuozhe)&(db.lianxi.keshi==keshi_id)).select(    
                                                                       db.timu.wenti,db.lianxi.bianhao,
                                                                       db.zuoti.zuozhe,db.zuoti.zuoda,
                                                                       db.timu.daan,orderby=db.lianxi.bianhao,
                                                                       join=db.lianxi.on(
                                                                                         (db.lianxi.timu==db.timu.id)&
                                                                                         (db.zuoti.lianxi==db.lianxi.id))
                                                                       )
    
    n=0
    right=0
    for row in rows:
        n=n+1
        if row.zuoti.zuoda==row.timu.daan:
            right=right+1
    cj=int(right/n)
    if not db.defen((db.defen.keshi==keshi_id)&(db.defen.xuesheng==zuozhe)):
        db.defen.insert(keshi=keshi_id,xuesheng=auth.user_id,chengji=cj)
    return dict(record=rows,cj=cj)

def zuoye():
    zuozhe=auth.user_id
    keshi_id=request.args[0]
    crud=Crud(db)
    if db.zuoye(db.zuoye.zuozhe==zuozhe):
        db.zuoye.defen.writable=False
        zuoye_id=db.zuoye(db.zuoye.zuozhe==zuozhe).id
        form=crud.update(db.zuoye,zuoye_id,deletable=False,next=request.url)
        db.zuoye.defen.writable=True
    else:
        db.zuoye.zuozhe.default=zuozhe
        db.zuoye.keshi.default=keshi_id
        db.zuoye.defen.writable=False
        form=crud.create(db.zuoye,next=request.url)
      #  db.zuoye.zuozhe.default=None
        db.zuoye.keshi.default=None
        db.zuoye.defen.writable=True
    return dict(form=form)
    
def lianxi():
    zuozhe=auth.user_id
    keshi_id=request.args[0]
    crud=Crud(db)
    lianxi=db(db.lianxi.keshi==keshi_id).select(orderby=db.lianxi.bianhao)
    values=None
    '''
    forms=[]
    for l in lianxi:
        form=FORM(db.timu(l.timu).wenti,
                  INPUT(_type='hidden',_name='formname',value=l.id),
                  INPUT(_name='zuoda'),
                  INPUT(_type='submit') ,
                  keepvalues=True)
        form._formname=l.id
        forms.append(form)
    '''
    form=FORM('lianxi',
                  keepvalues=True)
    for l in lianxi:      
        form.append(db.timu(l.timu).wenti)
        form.append(INPUT(_name=l.id))
        form.append(BR())
    form.append(INPUT(_type='submit'))
    if form.process().accepted:
        for (lx,zd) in form.vars.items():
            db.zuoti.update_or_insert(lianxi=lx,zuozhe=zuozhe,zuoda=zd)
    return dict(form=form)
    
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())

def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)

def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()


@auth.requires_signature()
def data():
    """
    http://..../[app]/default/data/tables
    http://..../[app]/default/data/create/[table]
    http://..../[app]/default/data/read/[table]/[id]
    http://..../[app]/default/data/update/[table]/[id]
    http://..../[app]/default/data/delete/[table]/[id]
    http://..../[app]/default/data/select/[table]
    http://..../[app]/default/data/search/[table]
    but URLs must be signed, i.e. linked with
      A('table',_href=URL('data/tables',user_signature=True))
    or with the signed load operator
      LOAD('default','data.load',args='tables',ajax=True,user_signature=True)
    """
    return dict(form=crud())
